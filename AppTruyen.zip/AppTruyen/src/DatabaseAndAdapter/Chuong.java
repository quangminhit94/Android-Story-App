package DatabaseAndAdapter;

import java.io.Serializable;

public class Chuong implements Serializable{
       public String tentruyen,chuong,noidung;
	public Chuong() {
	}
	public Chuong( String tentruyen, String chuong,String noidung) {
		this.tentruyen = tentruyen;
		this.chuong = chuong;
		this.noidung = noidung;
	}
	
}
