package DatabaseAndAdapter;

import java.util.List;

import com.example.doctruyen.R;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

public class ChuongAdapter extends ArrayAdapter<Chuong> implements Filterable {
	LayoutInflater inflater;
	Activity context;
	public ChuongAdapter(Activity context, List<Chuong> list) {
		super(context, R.layout.hienthichuong, list);
		inflater = context.getLayoutInflater();
	}
   @Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View v = inflater.inflate(R.layout.hienthichuong, null);
		TextView txt1 = (TextView)v.findViewById(R.id.textView12);
		ImageView img = (ImageView)v.findViewById(R.id.imageView1);
		ImageView img2 = (ImageView)v.findViewById(R.id.imageView2);
		Chuong ch = getItem(position);
		txt1.setText(ch.chuong);
		img.setImageResource(R.drawable.black);
		img2.setImageResource(R.drawable.plane);
		return v;
	}
  
}
