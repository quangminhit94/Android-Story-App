package DatabaseAndAdapter;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {
    private static String DB_NAME = "apptruyen.sqlite";
    Context context;
	String duongDanDatabase = "";
	public DBHelper(Context context) {
		super(context, DB_NAME, null, 2);
	    this.context = context;
	    duongDanDatabase =context.getFilesDir().getParent() + "/databases/" + DB_NAME;
	}
	public void copyDatabase(){
		try {
			InputStream is =  context.getAssets().open(DB_NAME);
			OutputStream os = new FileOutputStream(duongDanDatabase);
			byte[] buffer = new byte[1024];
			int lenght = 0;
			while((lenght = is.read(buffer)) > 0){
				os.write(buffer, 0, lenght);
			}
			os.flush();
			os.close();
			is.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void createDatabase(){
		boolean kt = KiemTraDB();
		if(kt){
			Log.d("KetNoi", "Máy đã có database");
		}else{
			Log.d("KetNoi", "Máy chưa có database tiến hành copy dữ liệu");
			this.getWritableDatabase();
			copyDatabase();
		}
	}
	public SQLiteDatabase openDatabase(){
		return SQLiteDatabase.openDatabase(duongDanDatabase, null, SQLiteDatabase.OPEN_READWRITE);
	}
	
	public boolean KiemTraDB(){
		SQLiteDatabase kiemTraDB = null;
		try{
			kiemTraDB = SQLiteDatabase.openDatabase(duongDanDatabase, null, SQLiteDatabase.OPEN_READONLY);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(kiemTraDB !=null){
			kiemTraDB.close();
		}
		return kiemTraDB !=null ? true : false;
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		
	}

}
