package DatabaseAndAdapter;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class SQLDatabaseSource {
	SQLiteDatabase db;
	DBHelper helper;
	
	public SQLDatabaseSource(Context context) {
		helper = new DBHelper(context);
		helper.createDatabase();
		db = helper.openDatabase();
	}
	public ArrayList<Truyen> getTruyen(){
		SQLiteDatabase db = helper.openDatabase();
		String sql = "Select tentruyen,theloai from truyen";
		Cursor c = db.rawQuery(sql, null);
		ArrayList<Truyen> list = new ArrayList<Truyen>();
		while(c.moveToNext()){
			Truyen tr = new Truyen();
			tr.tentruyen = c.getString(0);
			tr.theloai = c.getString(1);
			list.add(tr);
		}
		return list;
	}
}
