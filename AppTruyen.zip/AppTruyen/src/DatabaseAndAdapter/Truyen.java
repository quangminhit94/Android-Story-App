package DatabaseAndAdapter;

public class Truyen {
   public int id;
   public String tentruyen;
   public String theloai;
   public String chuong;
   public String noidung,tacgia;
   
   public Truyen(){
	   
   }

public Truyen(int id, String tentruyen, String theloai, String chuong, String noidung, String tacgia) {
	super();
	this.id = id;
	this.tentruyen = tentruyen;
	this.theloai = theloai;
	this.chuong = chuong;
	this.noidung = noidung;
	this.tacgia = tacgia;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getTentruyen() {
	return tentruyen;
}

public void setTentruyen(String tentruyen) {
	this.tentruyen = tentruyen;
}

public String getTheloai() {
	return theloai;
}

public void setTheloai(String theloai) {
	this.theloai = theloai;
}

public String getChuong() {
	return chuong;
}

public void setChuong(String chuong) {
	this.chuong = chuong;
}

public String getNoidung() {
	return noidung;
}

public void setNoidung(String noidung) {
	this.noidung = noidung;
}

public String getTacgia() {
	return tacgia;
}

public void setTacgia(String tacgia) {
	this.tacgia = tacgia;
}

   
   
}
