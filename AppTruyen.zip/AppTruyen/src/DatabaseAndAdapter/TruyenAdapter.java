package DatabaseAndAdapter;

import java.util.ArrayList;
import java.util.List;

import com.example.doctruyen.R;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import truyendai.HienThiChuong;

public class TruyenAdapter extends BaseAdapter	 implements View.OnClickListener, View.OnLongClickListener  {
	public Context context;
	boolean isClicked=false;
	List<String> listtruyen=new ArrayList<String>();
	String tentruyen;
	 public ArrayList<Truyen> list;
	 LayoutInflater inflater;
	 DBHelper helper;
		public class ViewHolder {
			 ImageView img;
			 TextView texttheloai;
			 TextView texttentruyen;
			  ToggleButton tg;
			}
  public TruyenAdapter(Context context , List<Truyen> list) {
	   super();
		inflater = LayoutInflater.from(context);
		this.context = context;
		this.list = (ArrayList<Truyen>) list;
	}
  
  @Override
	public View getView(final int position, View convertView, ViewGroup parent) {
	   final ViewHolder holder;
	if(convertView == null){   
		convertView= inflater.inflate(R.layout.hienthitruyennguoidung, null);
		holder = new ViewHolder();
		holder.img = (ImageView)convertView.findViewById(R.id.imageView1);
		holder.texttentruyen = (TextView)convertView.findViewById(R.id.textViewTenTruyen);
		holder.tg = (ToggleButton)convertView.findViewById(R.id.toggleButton1);
		holder.texttheloai = (TextView)convertView.findViewById(R.id.textViewTheloai);
          convertView.setTag(holder);
	}else{
		holder = (ViewHolder)convertView.getTag();
	}
	helper = new DBHelper(context);
	SQLiteDatabase db = helper.getWritableDatabase();
	Cursor c=db.rawQuery("select tentruyen from yeuthich ", null);
	while (c.moveToNext()) {
		tentruyen=c.getString(0);		
		listtruyen.add(tentruyen);
	}
	
	final Truyen tr = list.get(position);
	if (listtruyen.size()>0) {
		
		for (int i = 0; i < listtruyen.size(); i++) {
			if (listtruyen.get(i).equals(tr.tentruyen)) {
				 holder.tg.setBackgroundResource(R.drawable.heart);
				 isClicked=true;
			}
		}
	}
	if(list!=null){
	holder.texttentruyen.setText(tr.tentruyen);
	holder.texttheloai.setText(tr.theloai);
	holder.img.setImageResource(R.drawable.iconbook);
	}

	 convertView.setOnClickListener(new OnClickListener() {

		@Override
		public void onClick(View v) {
			helper = new DBHelper(context);
			SQLiteDatabase db = helper.getWritableDatabase();
			Cursor c=db.rawQuery("select * from truyen where tentruyen=?", new String[]{(list.get(position).tentruyen)});
			String tentruyen = null;
			while (c.moveToNext()) {
				tentruyen=c.getString(0);					
			}
			Intent intent = new Intent(context, HienThiChuong.class);
			intent.putExtra("tentruyen", tentruyen);
			context.startActivity(intent);
		}
    });
	 holder.tg.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {
			 if(!isClicked){
				 isClicked=true;
				 holder.tg.setBackgroundResource(R.drawable.heart);
				 helper = new DBHelper(context);
					SQLiteDatabase db = helper.getWritableDatabase();
				 ContentValues values=new ContentValues();
					values.put("tentruyen", tr.tentruyen);
					values.put("theloai", tr.theloai);
					long rows=db.insert("yeuthich", null, values);
					if (rows>0) {
						 Toast.makeText(context, "Bạn đã thêm vào mục yêu thích", Toast.LENGTH_SHORT).show();
					}
			 }else {
				 isClicked=false;
				 helper = new DBHelper(context);
					SQLiteDatabase db = helper.getWritableDatabase();
				 holder.tg.setBackgroundResource(R.drawable.heart1);
				 long rows =db.delete("yeuthich","tentruyen=?", new String[]{tr.tentruyen});
					if (rows>0) {
						Toast.makeText(context, "Bạn đã loại khỏi mục yêu thích", Toast.LENGTH_SHORT).show();
					}
			 }
		}
	});
	return convertView;
	
	}
@Override
public int getCount() {
	int rtvalue = 0;
	if(list!=null){
		rtvalue = list.size();
	}
	return rtvalue;
}
@Override
public Object getItem(int position) {
	// TODO Auto-generated method stub
	return list.get(position);
}
@Override
public long getItemId(int position) {
	// TODO Auto-generated method stub
	return position;
}
public TruyenAdapter(View itemView) {
	itemView.setOnClickListener(this);
	itemView.setOnLongClickListener(this);
	
}
@Override
public boolean onLongClick(View v) {
	return false;
	
	
}
@Override
public void onClick(View v) {
	// TODO Auto-generated method stub
	
}
}
