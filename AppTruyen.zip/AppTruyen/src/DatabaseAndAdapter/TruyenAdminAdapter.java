package DatabaseAndAdapter;

import java.util.ArrayList;

import com.example.doctruyen.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class TruyenAdminAdapter extends BaseAdapter {
  LayoutInflater inflater;
  ArrayList<Truyen> list ;
  Context context;
  
	public TruyenAdminAdapter(Context context, ArrayList<Truyen> list) {
		super();
		this.list = list;
		inflater = LayoutInflater.from(context);
	}
	public class ViewHolder{
		TextView txttl,txttr;
	}
	ViewHolder holder;
	
   @Override
	public View getView(int position, View convertView, ViewGroup parent) {
	   if(convertView==null){
		   convertView = inflater.inflate(R.layout.hienthitruyenadmin, null);
		   holder = new ViewHolder();
		   holder.txttl = (TextView)convertView.findViewById(R.id.textView1);
		   holder.txttr = (TextView)convertView.findViewById(R.id.textView2);
		   convertView.setTag(holder);
	   }else{
		   holder = (ViewHolder)convertView.getTag();
	   }
		if(list!=null){
			Truyen tr = list.get(position);
			holder.txttl.setText(tr.theloai);
			holder.txttr.setText(tr.tentruyen);
		}
		return convertView;
	}
@Override
public int getCount() {
	// TODO Auto-generated method stub
	return list.size();
}
@Override
public Object getItem(int position) {
	// TODO Auto-generated method stub
	return list.get(position);
}
@Override
public long getItemId(int position) {
	// TODO Auto-generated method stub
	return position;
}
}
