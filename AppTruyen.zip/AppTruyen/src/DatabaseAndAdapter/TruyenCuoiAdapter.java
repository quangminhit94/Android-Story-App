package DatabaseAndAdapter;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.example.doctruyen.R;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import nl.siegmann.epublib.domain.Book;
import nl.siegmann.epublib.domain.TOCReference;
import nl.siegmann.epublib.epub.EpubReader;
import truyencuoi.RowData;

public class TruyenCuoiAdapter extends BaseAdapter implements Filterable{
  public Context context;
  LayoutInflater inflater;
  private ValueFilter valueFilter;
  private ArrayList<String> mStringFilterList;
  boolean isClicked;
  private ArrayList<RowData> contentDetails;
	public static final String BOOK_NAME = "truyencuoi.epub";
	ArrayList<String> simpletitle=new ArrayList<String>();
	
	
   public TruyenCuoiAdapter(Context context , ArrayList<String> simpletitle) {
	   inflater = LayoutInflater.from(context);
	 this.context = context;
	 this.simpletitle = simpletitle;
	 this.mStringFilterList= simpletitle;
	 getFilter();
}
    public class ViewHolder{
    	ImageView img,img1;
    	TextView txt;
    }
    
    
	@Override
	public int getCount() {
		int rtvalue = 0;
		if(simpletitle!=null){
			rtvalue = simpletitle.size();
		}
		return rtvalue;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return simpletitle.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	ViewHolder holder;
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		if(convertView==null){
			convertView = inflater.inflate(R.layout.truyencuoi_adapter, null);
			holder = new ViewHolder();
			holder.img = (ImageView)convertView.findViewById(R.id.imageView1);
			holder.img1= (ImageView)convertView.findViewById(R.id.imageView2);
			holder.txt = (TextView)convertView.findViewById(R.id.textView1);
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder)convertView.getTag();
		}if(simpletitle!=null){
			holder.img.setImageResource(R.drawable.iconcuoi);
			holder.img1.setImageResource(R.drawable.plane);
		}
		contentDetails = new ArrayList<RowData>();
		AssetManager assetManager = context.getAssets();
		try {
			InputStream epubInputStream = assetManager.open(BOOK_NAME);
			Book book = (new EpubReader()).readEpub(epubInputStream);
			logContentsTable(book.getTableOfContents().getTocReferences(), 0);
		} catch (IOException e) {
			Log.e("epublib", e.getMessage());
		}
		if(simpletitle!=null){
			holder.txt.setText(simpletitle.get(position).toString());
		}
		
		
		return convertView;
	}
	private void logContentsTable(List<TOCReference> tocReferences, int depth) {
		if (tocReferences == null) {
			return;
		}
		for (TOCReference tocReference : tocReferences) {
			StringBuilder tocString = new StringBuilder();
			for (int i = 0; i < depth; i++) {
				tocString.append("\t");
			}
			tocString.append(tocReference.getTitle());
			RowData row = new RowData();
			row.setTitle(tocString.toString());
			row.setResource(tocReference.getResource());
			contentDetails.add(row);
			logContentsTable(tocReference.getChildren(), depth + 1);
		}
	}

	@Override
	public Filter getFilter() {
		if(valueFilter==null) {
	        valueFilter=new ValueFilter();
	    }
	    return valueFilter;
	}
	private class ValueFilter extends Filter {

	    @Override
	    protected FilterResults performFiltering(CharSequence constraint) {

	        FilterResults results=new FilterResults();

	        if(constraint!=null && constraint.length()>0){

	            ArrayList<String> filterList=new ArrayList<String>();

	            for(int i=0;i<mStringFilterList.size();i++){

	                if(mStringFilterList.get(i).contains(constraint)) {

	                    filterList.add(mStringFilterList.get(i));

	                }
	            }

	            results.count=filterList.size();

	            results.values=filterList;

	        }else{

	            results.count=mStringFilterList.size();

	            results.values=mStringFilterList;

	        }

	        return results;
	    }
	    @SuppressWarnings("unchecked")
		@Override
		protected void publishResults(CharSequence constraint, FilterResults results) {
			simpletitle=(ArrayList<String>) results.values;

	        notifyDataSetChanged();
			
		}
	}
}
