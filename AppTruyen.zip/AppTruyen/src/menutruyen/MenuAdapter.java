package menutruyen;

import java.util.ArrayList;
import java.util.List;

import com.example.doctruyen.R;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


public class MenuAdapter extends BaseAdapter {
	LayoutInflater inflater;
	String[] trangchu = {"Truyện Dài","Truyện Cười","Truyện Ngắn","Góp Ý","Thoát"};
	int[] icon={R.drawable.readbook,R.drawable.readbook,R.drawable.readbook,R.drawable.readbook,R.drawable.readbook};//....
	static List<Menu_Data> list=new ArrayList<Menu_Data>();
   Activity context;
	public MenuAdapter(Activity context) {
		super();
		MenuAdapter.list = list;
		list.clear();
		for (int i = 0; i < trangchu.length; i++) {
			list.add(new Menu_Data(trangchu[i], icon[i]));
		}
		inflater = LayoutInflater.from(context);
	}
	public class ViewHolder{
		TextView txtmenuname;
		ImageView img;
	}
	ViewHolder holder;
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if(convertView == null){
			  convertView = inflater.inflate(R.layout.menu_adapter, null);
			  holder = new ViewHolder();
			  holder.txtmenuname = (TextView)convertView.findViewById(R.id.menuname);
			  holder.img = (ImageView)convertView.findViewById(R.id.menu_icon);
			  convertView.setTag(holder);
		}else{
			holder = (ViewHolder)convertView.getTag();
		}
		if(list!=null){
		Menu_Data m=list.get(position);
		holder.txtmenuname.setText(m.menuname);
		holder.img.setImageResource(m.menuicon);
		}
		return convertView;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}
	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}
	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
}