package menutruyen;

public class Menu_Data {
	public String menuname;public int menuicon;
	public Menu_Data(String menuname,int menuicon) {
		this.menuicon=menuicon;
		this.menuname=menuname;
	}
}
