package quanlytruyen;

import java.util.ArrayList;

import com.example.doctruyen.R;

import DatabaseAndAdapter.DBHelper;
import DatabaseAndAdapter.SQLDatabaseSource;
import DatabaseAndAdapter.TruyenAdminAdapter;
import DatabaseAndAdapter.Truyen;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class HienThiTruyenThemChuong extends Activity {
	 DBHelper helper;
	 ListView lv;
	 ArrayList<Truyen> list = new ArrayList<Truyen>();
	 TruyenAdminAdapter adapter;
	 Truyen tr = new Truyen();
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hienthi_tentruyen);
		SQLDatabaseSource db;
		db = new SQLDatabaseSource(this);
		lv = (ListView)findViewById(R.id.listView1);
		adapter = new TruyenAdminAdapter(HienThiTruyenThemChuong.this,list);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				helper = new DBHelper(HienThiTruyenThemChuong.this);
				SQLiteDatabase db = helper.openDatabase();
				Cursor c=db.rawQuery("select * from truyen where tentruyen=?", new String[]{list.get(position).tentruyen});
				String tentruyen = null;
				while (c.moveToNext()) {
					tentruyen=c.getString(0);					
				}
				Intent intent = new Intent(HienThiTruyenThemChuong.this, Themchuong.class);
				intent.putExtra("tentruyen", tentruyen);
				startActivity(intent);
			}
		});
		upload();
	}
	public void upload(){
		list.clear();
		helper = new DBHelper(HienThiTruyenThemChuong.this);
		SQLiteDatabase db = helper.openDatabase();
		Cursor c = db.rawQuery("Select tentruyen,theloai from truyen", null);
		while(c.moveToNext()){
			Truyen tr = new Truyen();
			tr.tentruyen = c.getString(0);
			tr.theloai = c.getString(1);
			list.add(tr);
		}
		adapter.notifyDataSetChanged();
	}
}
