package quanlytruyen;

import truyendai.GUIActivity1;
import truyendai.HienThiTruyen;

import com.example.doctruyen.R;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class MainActivity extends ActivityGroup {
TabHost tab;
TabSpec tab1,tab2,tab3;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		 tab = (TabHost) findViewById(R.id.tabhost);
		 tab.setup(getLocalActivityManager());
		 
		 tab1 = tab.newTabSpec("");
		 tab1.setIndicator("Thêm Truyện");
		 tab1.setContent(new Intent(this, Themtruyen.class));
		 tab.addTab(tab1);
		 
	/*	 tab2 = tab.newTabSpec("");
		 tab2.setIndicator("Danh Sách Truyện");
		 tab2.setContent(new Intent(this, HienThiTruyenTrongPhanHienThi.class));
		 tab.addTab(tab2);*/
		 

		 tab3 = tab.newTabSpec("");
		 tab3.setIndicator("Thêm Chương Truyện");
		 tab3.setContent(new Intent(this, HienThiTruyenThemChuong.class));
		 tab.addTab(tab3);
		 
		 tab.setCurrentTab(0);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menuback, menu);
		return true;
	}
	@Override
		public boolean onMenuItemSelected(int featureId, MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.item1) {
			Intent intent = new Intent(this, GUIActivity1.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
			startActivity(intent);
			
		}
		
			return super.onMenuItemSelected(featureId, item);
		}
}
