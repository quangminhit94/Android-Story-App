package quanlytruyen;

import java.util.ArrayList;

import com.example.doctruyen.R;

import DatabaseAndAdapter.ChuongAdapter;
import DatabaseAndAdapter.DBHelper;
import DatabaseAndAdapter.SQLDatabaseSource;
import DatabaseAndAdapter.Chuong;
import DatabaseAndAdapter.Truyen;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Themchuong extends Activity {
EditText ed1,ed2;
DBHelper helper;
ListView lv;
int position1;
TextView tv;
String noidung;
String tentruyen;
ArrayList<Chuong> list = new ArrayList<Chuong>();
ArrayList<Truyen> list1 = new ArrayList<Truyen>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_themchuong);
		Intent intent=getIntent();
		tentruyen=intent.getStringExtra("tentruyen");
		
		
		SQLDatabaseSource db;
		db = new SQLDatabaseSource(this);
		tv=(TextView) findViewById(R.id.tvTenTruyen);
		ed1 = (EditText)findViewById(R.id.editText1);
		ed2 = (EditText)findViewById(R.id.editText2);
		lv = (ListView)findViewById(R.id.listView1);
		lv.setAdapter(new ChuongAdapter(this, list));
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Chuong ch = list.get(position);
				ed1.setText(ch.chuong);
				
			}
		});
		lv.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
				Chuong ch = list.get(position);
				 AlertDialog.Builder builder = new AlertDialog.Builder(Themchuong.this);
				 builder.setIcon(android.R.drawable.ic_delete).setTitle("Xóa");
				 builder.setMessage(" Bạn có muốn xóa không ?")
				        .setPositiveButton("Ok", new OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								helper = new DBHelper(Themchuong.this);
								SQLiteDatabase db = helper.getWritableDatabase();
					     long rows =db.delete("chuongtruyen", "tenchuong=?",new String[]{list.get(position).chuong});
								
								if(rows > 0){
									Toast.makeText(Themchuong.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
									updateload();
								}else{
									Toast.makeText(Themchuong.this, "Xóa thất bại", Toast.LENGTH_SHORT).show();
								}
								
							}
						}).setNegativeButton("Cancel", new OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialog, int which) {
								dialog.cancel();
								
							}
						});
				builder.create().show();;
				
				return true;
			}
		});
		tv.setText("Tên truyện:"+tentruyen);
		updateload();;
	}
	public void updateload(){
		list.clear();
		helper = new DBHelper(Themchuong.this);
		SQLiteDatabase db = helper.getWritableDatabase();
		Cursor c = db.rawQuery("Select tenchuong from chuongtruyen where tentruyen=?",new String[]{tentruyen});
		while(c.moveToNext()){
			 Chuong ch = new Chuong();
			 ch.chuong = c.getString(0);
			 list.add(ch);
		}
		lv.setAdapter(new ChuongAdapter(this, list));
	}
	public void reset(View v){
		ed1.setText("");
		ed2.setText("");
	}
	public void update(View v){
	
		helper = new DBHelper(Themchuong.this);
		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("tenchuong", ed1.getText().toString());
		values.put("noidung", ed2.getText().toString());
		 long rows =db.update("chuongtruyen", values, "tenchuong=?",new String[]{list.get(position1).chuong});
		if(rows > 0){
			Toast.makeText(this, "Sửa thành công", Toast.LENGTH_SHORT).show();
			updateload();
		}else{
			Toast.makeText(this, "Sửa thất bại", Toast.LENGTH_SHORT).show();
		}
	}
	public void them(View v){
		if(ed1.getText().toString().length()==0){
			ed1.setError("Bạn phải nhập Tên Chương");
			return;
		}
		if(ed2.getText().toString().length()==0){
			ed2.setError("Bạn phải nhập Thể Nội Dung");
			return;
		}
		helper = new DBHelper(Themchuong.this);
		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("tenchuong", ed1.getText().toString());
		values.put("noidung", ed2.getText().toString());
		values.put("tentruyen", tentruyen);
		long rows = db.insert("chuongtruyen", null, values);
		
		if(rows > 0){
			Toast.makeText(this, "Thêm thành công", Toast.LENGTH_SHORT).show();
			updateload();
		}else{
			Toast.makeText(this, "Thêm thất bại", Toast.LENGTH_SHORT).show();
		}
		
	}
}
