package quanlytruyen;

import java.util.ArrayList;
import java.util.List;

import com.example.doctruyen.R;

import DatabaseAndAdapter.DBHelper;
import DatabaseAndAdapter.SQLDatabaseSource;
import DatabaseAndAdapter.TruyenAdminAdapter;
import DatabaseAndAdapter.Truyen;
import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

public class Themtruyen extends Activity {
 DBHelper helper;
 EditText ed1,ed2;
 ArrayList<Truyen> list = new ArrayList<Truyen>();
 ListView lv;
 String tentruyen;
 int position1;
 Spinner spn;
 String [] theloai = {"Phiêu Lưu","Học Đường","Tình Cảm"};
 TruyenAdminAdapter adapter;
List<String> listtl = new ArrayList<String>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_themtruyen);
		SQLDatabaseSource db;
		db = new SQLDatabaseSource(this);
		ed2 = (EditText)findViewById(R.id.editText2);
	    lv = (ListView)findViewById(R.id.listView1);
	    spn = (Spinner)findViewById(R.id.spinnerTheLoai);
	    ArrayAdapter<String> adapterSpn = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,theloai);
	    spn.setAdapter(adapterSpn);
	    lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				position1=position;
				ed2.setText(list.get(position).tentruyen);
				if(list.get(position).theloai.equals("Phiêu Lưu")){
					spn.setSelection(0);
				}else if(list.get(position).theloai.equals("Học Đường")){
					spn.setSelection(1);
				}else if(list.get(position).theloai.equals("Tình Cảm")){
					spn.setSelection(2);
				}
			}
		});
	   
	    adapter = new TruyenAdminAdapter(this, list);
	    lv.setAdapter(adapter);
	    showtruyen();
	}
	
	public void update(View v){
		if(ed2.getText().toString().length()==0){
			ed2.setError("Bạn phải nhập Tên Truyện");
			return;
		}
	    helper = new DBHelper(this);
	    SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("tentruyen", ed2.getText().toString());
		values.put("theloai", spn.getSelectedItem().toString());
		long rows = db.update("truyen", values, "tentruyen=?", new String[]{list.get(position1).tentruyen});
		if(rows > 0){
			 Toast.makeText(this, "Sửa thành công !",Toast.LENGTH_SHORT).show();
		} else {
			 Toast.makeText(this, "Sửa thất bại !",Toast.LENGTH_SHORT).show();
		}
		showtruyen();
	}
	public void xoa(View v){
		 helper = new DBHelper(this);
		    SQLiteDatabase db = helper.getWritableDatabase();
		if(ed2.getText().toString().length()==0){
			ed2.setError("Bạn phải nhập Tên Truyện");
			return;
		}
		long rows = db.delete("truyen", "tentruyen=?", new String[]{list.get(position1).tentruyen});
		if(rows > 0){
			 Toast.makeText(this, "Xóa thành công !",Toast.LENGTH_SHORT).show();
			 showtruyen();
		} else {
			 Toast.makeText(this, "Xóa thất bại !",Toast.LENGTH_SHORT).show();
		}
		
	}
	public void showtruyen(){
		list.clear();
		 helper = new DBHelper(this);
		 SQLiteDatabase db = helper.openDatabase();
		Cursor c = db.rawQuery("Select tentruyen,theloai from truyen", null);
		while(c.moveToNext()){
			Truyen tr = new Truyen();
			tr.tentruyen = c.getString(0);
			tr.theloai = c.getString(1);
			list.add(tr);
		}
		adapter.notifyDataSetChanged();
	}
	public void reset(View v){
		ed2.setText("");
		spn.setSelection(0);
	}
	public void them(View v){
		if(ed2.getText().toString().length()==0){
			ed2.setError("Bạn phải nhập Tên Truyện");
			return;
		}
		helper = new DBHelper(this);
	    SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("tentruyen", ed2.getText().toString());
		values.put("theloai", spn.getSelectedItem().toString());
		long rows = db.insert("truyen", null, values);
		if(rows > 0){
 		   Toast.makeText(this, "Thêm thành công !",Toast.LENGTH_SHORT).show();
 		   showtruyen();
 	   }else{
 		   Toast.makeText(this, "Thêm thất bại !",Toast.LENGTH_SHORT).show();
 	   }
		}
	}
