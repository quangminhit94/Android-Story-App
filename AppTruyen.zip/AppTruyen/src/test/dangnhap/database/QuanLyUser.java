package test.dangnhap.database;

import java.util.ArrayList;
import java.util.HashMap;

import test.dangnhap.thuvien.ThuVienThoiGian;

import DatabaseAndAdapter.DBHelper;
import DatabaseAndAdapter.SQLDatabaseSource;
import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

public class QuanLyUser {

	DBHelper helper;
	Activity activity;

	public QuanLyUser(Activity activity) {
		this.activity = activity;
		SQLDatabaseSource db;
		db = new SQLDatabaseSource(activity);
		
	}

	// dang ky
	public boolean dangKy(NguoiDung nguoidung) {
		boolean kiemtra = true;
		helper = new DBHelper(activity);
		SQLiteDatabase db= helper.getWritableDatabase();
		ContentValues values = new ContentValues();

		values.put("NguoiDungID", nguoidung.getNguoiDungID());
		values.put("HoTen", nguoidung.getHoTen());
		values.put("TenDangNhap", nguoidung.getTenDangNhap());
		values.put("MatKhau", nguoidung.getMatKhau());
		values.put("CauHoi", nguoidung.getCauHoiBaoMat());
		values.put("TraLoi", nguoidung.getCauTraLoi());
		values.put("NgayTao", nguoidung.getNgayTao());
		values.put("NgayCapNhat", nguoidung.getNgayCapNhat());
		values.put("DangNhapLanCuoi", nguoidung.getNgayDangNhap());
		values.put("Role", 0);
		values.put("HinhAnh", nguoidung.getHinhAnh());
		// insert the row
		try {
			long rowInserted = db.insertWithOnConflict("nguoidung", null,
					values, SQLiteDatabase.CONFLICT_FAIL);
			if (rowInserted != -1) {
				kiemtra = true;
				Toast.makeText(activity, "Đăng ký Thành Công",
						Toast.LENGTH_SHORT).show();
			}

		} catch (Exception e) {
			kiemtra = false;
			Toast.makeText(activity, "Tên Đăng Nhập Đã Có Người Sử Dụng",
					Toast.LENGTH_SHORT).show();
		}

		db.close(); // Closing database connection
		return kiemtra;
	}

	// Dang nhap
	public String dangNhap(String username) {
		helper = new DBHelper(activity);
		SQLiteDatabase db= helper.openDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM nguoidung WHERE TenDangNhap=? And Role=0",
							new String[] { username });
		if (cursor.getCount() < 1) {
			cursor.close();
			return "Khong co";
		} else {
			cursor.moveToFirst();
			String password = cursor
					.getString(cursor.getColumnIndex("MatKhau"));

			// moi lan dang nhap sua lai thoi gian
			String NguoiDungId = cursor.getString(cursor
					.getColumnIndex("TenDangNhap"));
			suaThoiGianDangNhap(NguoiDungId);

			cursor.close();
			return password;
		}

	}

	// moi lan dang nhap sua lai thoi gian
	public void suaThoiGianDangNhap(String username) {
		helper = new DBHelper(activity);
		SQLiteDatabase db= helper.getWritableDatabase();
		ThuVienThoiGian thoigian = new ThuVienThoiGian();
		ContentValues values = new ContentValues();
		values.put("DangNhapLanCuoi", thoigian.getDateTime());
		String whereClause = "TenDangNhap =?";
		String[] whereArgs = new String[] { username };

		db.update("nguoidung", values, whereClause, whereArgs);
	}

	// Sua ho ten khi dang nhap thanh cong
	public void suaHoTen(String usename, String hoten, byte[] hinhanh) {
		helper = new DBHelper(activity);
		SQLiteDatabase db= helper.getWritableDatabase();
		ThuVienThoiGian thoigian = new ThuVienThoiGian();
		try {
		ContentValues values = new ContentValues();
		values.put("NgayCapNhat", thoigian.getDateTime());
		values.put("HoTen", hoten);
		values.put("HinhAnh", hinhanh);
		String whereClause = "TenDangNhap =?";
		String[] whereArgs = new String[] { usename };
		
			long rowInserted = db.update("nguoidung", values, whereClause, whereArgs);
			if (rowInserted != -1) {
				Toast.makeText(activity, "Sửa Thành Công",
						Toast.LENGTH_SHORT).show();
			}
			else{
				Toast.makeText(activity, "Sửa Thất Bại",
						Toast.LENGTH_SHORT).show();
			}
		} catch (Exception e) {
			Toast.makeText(activity, "Lỗi: "+e,
					Toast.LENGTH_SHORT).show();
		}
		
	}

	// Doi lai mat khau
	public void doiMatKhau(String username, String matkhaumoi) {
		helper = new DBHelper(activity);
		SQLiteDatabase db= helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("MatKhau", matkhaumoi);
		String whereClause = "TenDangNhap =?";
		String[] whereArgs = new String[] { username };
		db.update("nguoidung", values, whereClause, whereArgs);
	}
	
	// Doi lai mat khau
		public void quenMatKhau(String username, String matkhaumoi) {
			helper = new DBHelper(activity);
			SQLiteDatabase db= helper.getWritableDatabase();
			ContentValues values = new ContentValues();
			values.put("MatKhau", matkhaumoi);
			String whereClause = "TenDangNhap =?";
			String[] whereArgs = new String[] { username };
			db.update("nguoidung", values, whereClause, whereArgs);
		}

	/**
	 * Hien thi tren danh sach
	 * */
	public ArrayList<NguoiDung> selectData(String sql, String... selectionArgs) {
		ArrayList<NguoiDung> user = new ArrayList<NguoiDung>();
		helper = new DBHelper(activity);
		SQLiteDatabase db= helper.openDatabase();
		Cursor cursor = db.rawQuery(sql, selectionArgs);
		if (cursor.getCount() > 0) {
			while (cursor.moveToNext()) {
				NguoiDung nguoidung = new NguoiDung();
				nguoidung.setNguoiDungID(cursor.getString(cursor
						.getColumnIndex("NguoiDungID")));
				nguoidung.setHoTen(cursor.getString(cursor
						.getColumnIndex("HoTen")));
				nguoidung.setTenDangNhap(cursor.getString(cursor
						.getColumnIndex("TenDangNhap")));
				nguoidung.setMatKhau(cursor.getString(cursor
						.getColumnIndex("MatKhau")));
				nguoidung.setCauHoiBaoMat(cursor.getString(cursor
						.getColumnIndex("CauHoi")));
				nguoidung.setCauTraLoi(cursor.getString(cursor
						.getColumnIndex("TraLoi")));
				nguoidung.setNgayTao(cursor.getString(cursor
						.getColumnIndex("NgayTao")));
				nguoidung.setNgayCapNhat(cursor.getString(cursor
						.getColumnIndex("NgayCapNhat")));
				nguoidung.setNgayDangNhap(cursor.getString(cursor
						.getColumnIndex("DangNhapLanCuoi")));
				nguoidung.setRole(cursor.getString(cursor
						.getColumnIndex("Role")));
				nguoidung.setHinhAnh(cursor.getBlob(cursor
						.getColumnIndex("HinhAnh")));
				// Thêm vào danh sách
				user.add(nguoidung);
			}
		}
		cursor.close();
		db.close();
		// return user
		return user;
	}

	// Hien thi thong tin cua mot user theo ten dang nhap
	public NguoiDung ThongTinChiTietTheoTenDangNhap(String tendangnhap) {
		helper = new DBHelper(activity);
		SQLiteDatabase db= helper.openDatabase();
		String sql = "SELECT * FROM nguoidung WHERE TenDangNhap =?";
		ArrayList<NguoiDung> list = selectData(sql, String.valueOf(tendangnhap));
		return list.get(0);
	}

	/**
	 * Dem so luong voi chuc danh nguoi dung
	 * */ 
	public int soLuongNguoiDung() {
		helper = new DBHelper(activity);
		SQLiteDatabase db= helper.openDatabase();
		String countQuery = "SELECT  * FROM nguoidung where Role=0";
		
		Cursor cursor = db.rawQuery(countQuery, null);
		int rowCount = cursor.getCount();
		db.close();
		cursor.close();

		// return row count
		return rowCount;
	}

}
