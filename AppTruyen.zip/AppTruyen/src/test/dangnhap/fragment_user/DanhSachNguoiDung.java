package test.dangnhap.fragment_user;

import com.example.doctruyen.R;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class DanhSachNguoiDung extends Fragment {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.danhsachnguoidung, container, false);
		
		return rootView;
	}
}
