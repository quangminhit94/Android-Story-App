package test.dangnhap.fragment_user;

import com.example.doctruyen.R;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import test.dangnhap.DungPreferences;
import test.dangnhap.database.NguoiDung;
import test.dangnhap.database.QuanLyUser;
import truyendai.HienThiTruyen;

public class DoiMatKhau extends Fragment implements OnClickListener {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.doimatkhau, container, false);
		matkhaucuEdt = (EditText) rootView.findViewById(R.id.matkhaucu_edt);
		matkhaumoiEdt = (EditText) rootView.findViewById(R.id.matkhaumoi_edt);
		doimatkhauBtn = (Button) rootView.findViewById(R.id.doimatkhau_btn);
		traloiEdt = (EditText) rootView.findViewById(R.id.traloi_edt);

		doimatkhauBtn.setOnClickListener(this);
		return rootView;
	}

	private EditText matkhaucuEdt;
	private EditText matkhaumoiEdt;
	private Button doimatkhauBtn;
	private EditText traloiEdt;

	@Override
	public void onClick(View v) {
		if (v == doimatkhauBtn) {
			if (validate()) {
				String newpass = matkhaumoiEdt.getText().toString();
				// lay chi tiet thong tin
				QuanLyUser quanLyUser = new QuanLyUser(getActivity());

				String username = DungPreferences.readString(getActivity(),
						DungPreferences.USER_NAME, null);
				quanLyUser.doiMatKhau(username, newpass);
				Toast.makeText(getActivity(), "Đổi mật khẩu thành công",
						Toast.LENGTH_LONG).show();
				Intent intent = new Intent(getActivity(),
						HienThiTruyen.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear
																// back
																// stack
				startActivity(intent);
				getActivity().finish();				

			} else {
				Toast.makeText(getActivity(), "Đổi mật khẩu thất bại",
						Toast.LENGTH_LONG).show();
			}
		}
	}

	// Bẫy lỗi bỏ trống
	public boolean validate() {
		boolean valid = true;

		String oldpass = matkhaucuEdt.getText().toString();
		String answer = traloiEdt.getText().toString();
		String newpass = matkhaumoiEdt.getText().toString();

		// lay chi tiet thong tin
		NguoiDung user = new NguoiDung();
		QuanLyUser quanLyUser = new QuanLyUser(getActivity());

		String username = DungPreferences.readString(getActivity(),
				DungPreferences.USER_NAME, null);


		if (containsWhiteSpace(newpass)) {
			matkhaumoiEdt.setError("Mật khẩu không chứa khoảng trắng");
			valid = false;
		} else if (newpass.isEmpty()) {
			matkhaumoiEdt.setError("Mật khẩu mới không được bỏ trống");
			valid = false;
		} else if (!newpass.matches("^[a-z0-9._-]{4,30}$")) {
			matkhaumoiEdt
					.setError("Mật khẩu cho phép từ 4 đến 30 ký tự và không chứa kí tự đặc biệt");
			valid = false;
		} else {
			matkhaumoiEdt.setError(null);
		}

		user = quanLyUser.ThongTinChiTietTheoTenDangNhap(username);

		if (!oldpass.equals(user.getMatKhau())) {
			matkhaucuEdt.setError("Sai Mật Khẩu cũ");
			valid = false;
		} else {
			matkhaucuEdt.setError(null);
		}
		if (!answer.equals(user.getCauTraLoi())) {
			traloiEdt.setError("Sai Câu Trả Lời Bảo Mật");
			valid = false;
		} else {
			traloiEdt.setError(null);
		}

		return valid;
	}
	
	public static boolean containsWhiteSpace(String line) {
		boolean space = false;
		if (line != null) {

			for (int i = 0; i < line.length(); i++) {

				if (line.charAt(i) == ' ') {
					space = true;
				}

			}
		}
		return space;
	}
}