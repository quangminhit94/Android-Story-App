package test.dangnhap.fragment_user;

import com.example.doctruyen.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import quanlytruyen.MainActivity;
import test.dangnhap.DungPreferences;
import test.dangnhap.database.NguoiDung;
import test.dangnhap.database.QuanLyUser;
import truyendai.HienThiTruyen;

public class Login extends Fragment implements View.OnClickListener {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.login, container, false);

		resetpassBtn = (Button) rootView.findViewById(R.id.resetpass_btn);
		usernameEdt = (EditText) rootView.findViewById(R.id.username_edt);
		dangnhapBtn = (Button) rootView.findViewById(R.id.dangnhap_btn);
		passwordEdt = (EditText) rootView.findViewById(R.id.password_edt);

		resetpassBtn.setOnClickListener(this);
		dangnhapBtn.setOnClickListener(this);

		return rootView;
	}

	private Button resetpassBtn;
	private EditText usernameEdt;
	private Button dangnhapBtn;
	private EditText passwordEdt;

	@Override
	public void onClick(View v) {

		if (v == resetpassBtn) {
			// Hiện diaglog quên mật khẩu
			showdialog();

		} else if (v == dangnhapBtn) {
			// Xử lý xong bẫy lỗi cơ sỡ dữ liệu
			String username = usernameEdt.getText().toString();
			String password = passwordEdt.getText().toString();
			QuanLyUser quanLyUser = new QuanLyUser(getActivity());

			try {
				String storedPassword = quanLyUser.dangNhap(username);
				if (storedPassword.equalsIgnoreCase("Khong co")) {
					usernameEdt.setError("Sai Tên Đăng Nhập");
				} else {
					passwordEdt.setError("Sai Mật Khẩu");
				}

				if (password.equals(storedPassword)) {
					usernameEdt.setError(null);
					passwordEdt.setError(null);
					Toast.makeText(getActivity(), "Đăng nhập thành công",
							Toast.LENGTH_LONG).show();

					// chuyen username ve trang navigation de show len
					// header
					DungPreferences.writeBoolean(getActivity(),
							DungPreferences.LOGGEDIN_SHARED_PREF, true);
					DungPreferences.writeString(getActivity(),
							DungPreferences.USER_NAME, username);

					// day neu chuyen qua trang hienthitruyen thi` luc nhan
					// nut back ko phai la trang login nua
					Intent intent = new Intent(getActivity(),
							HienThiTruyen.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear
																	// back
																	// stack
					startActivity(intent);
					getActivity().finish();
				}
				// XET ADMINS
				if (username.equals("admin") && password.equals("admin")) {
					Intent intent = new Intent(getActivity(),
							MainActivity.class);
					startActivity(intent);
				}
			} catch (Exception e) {
				Toast.makeText(getActivity(), "Lỗi đăng nhập: " + e,
						Toast.LENGTH_LONG).show();
			}

		}
	}

	EditText username;
	EditText answer;
	EditText newpass;

	// Hien thi dialog quen mat khau
	public void showdialog() {
		// Get the layout inflater
		LayoutInflater inflater = getActivity().getLayoutInflater();
		View view = inflater.inflate(R.layout.quenmatkhau, null);
		username = (EditText) view.findViewById(R.id.tendangnhap_edt);
		answer = (EditText) view.findViewById(R.id.traloi_edt);
		newpass = (EditText) view.findViewById(R.id.matkhaumoi_edt);

		// Fail
		final AlertDialog.Builder builder = new AlertDialog.Builder(
				getActivity());
		builder.setTitle("Quên Mật Khẩu").setView(view);
		builder.setNegativeButton("Gửi", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {

			}
		});
		builder.setPositiveButton("Bỏ qua",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {

					}
				});

		final AlertDialog dialog = builder.create();
		dialog.setCanceledOnTouchOutside(false);

		dialog.show();
		dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						Boolean wantToCloseDialog = true;
						// Do stuff, possibly set wantToCloseDialog to true
						// then...
						if (wantToCloseDialog)
							dialog.dismiss();

						// else dialog stays open. Make sure you have an obvious
						// way to close the dialog especially if you set
						// cancellable to false.
					}
				});
		dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						Boolean wantToCloseDialog = false;
						// Do stuff, possibly set wantToCloseDialog to true
						// then...

						if (bayLoiQuenMatKhau()) {
							String tendangnhap = username.getText().toString();
							String matkhaumoi = newpass.getText().toString();
							QuanLyUser quanLyUser = new QuanLyUser(
									getActivity());
							quanLyUser.doiMatKhau(tendangnhap, matkhaumoi);
							Toast.makeText(getActivity(),
									"Mật khẩu mới đã tạo thành công",
									Toast.LENGTH_LONG).show();
							wantToCloseDialog = true;
						} else {
							Toast.makeText(
									getActivity(),
									"Thông Tin chưa chính xác vui lòng thử lại",
									Toast.LENGTH_LONG).show();
							wantToCloseDialog = false;
						}

						if (wantToCloseDialog)
							dialog.dismiss();
						// else dialog stays open. Make sure you have an obvious
						// way to close the dialog especially if you set
						// cancellable to false.
					}
				});
	}

	// Bẫy lỗi bỏ trống
	public boolean bayLoiQuenMatKhau() {
		boolean valid = true;

		String tendangnhap = username.getText().toString();
		String traloi = answer.getText().toString();
		String matkhaumoi = newpass.getText().toString();

		// lay chi tiet thong tin
		NguoiDung user = new NguoiDung();
		QuanLyUser quanLyUser = new QuanLyUser(getActivity());

		if (containsWhiteSpace(matkhaumoi)) {
			newpass.setError("Mật khẩu không chứa khoảng trắng");
			valid = false;
		} else if (matkhaumoi.isEmpty()) {
			newpass.setError("Mật khẩu không được bỏ trống");
			valid = false;
		} else if (!matkhaumoi.matches("^[a-z0-9._-]{4,30}$")) {
			newpass.setError("Mật khẩu cho phép từ 4 đến 30 ký tự và không chứa kí tự đặc biệt");
			valid = false;
		} else {
			newpass.setError(null);
		}

		try {
			user = quanLyUser.ThongTinChiTietTheoTenDangNhap(tendangnhap);

			if (!tendangnhap.equals(user.getTenDangNhap())) {
				username.setError("Sai Tên Đăng Nhập");
				valid = false;
			} else {
				username.setError(null);
			}
			if (!traloi.equals(user.getCauTraLoi())) {
				answer.setError("Sai Câu Trả Lời Bảo Mật");
				valid = false;
			} else {
				answer.setError(null);
			}
		} catch (Exception e) {
			username.setError("Sai Tên Đăng Nhập");
			valid = false;
		}

		return valid;
	}

	public static boolean containsWhiteSpace(String line) {
		boolean space = false;
		if (line != null) {

			for (int i = 0; i < line.length(); i++) {

				if (line.charAt(i) == ' ') {
					space = true;
				}
			}
		}
		return space;
	}
}
