package test.dangnhap.fragment_user;

import com.example.doctruyen.R;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import test.dangnhap.DungPreferences;
import test.dangnhap.database.NguoiDung;
import test.dangnhap.database.QuanLyUser;
import test.dangnhap.thuvien.ThuVienThoiGian;
import truyendai.HienThiTruyen;

public class Register extends Fragment implements View.OnClickListener {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View v = inflater.inflate(R.layout.register, container, false);

		tendangnhapEdt = (EditText) v.findViewById(R.id.tendangnhap_edt);
		passwordDkEdt = (EditText) v.findViewById(R.id.password_dk_edt);
		textView1 = (TextView) v.findViewById(R.id.textView1);
		cauhoibaomat = (Spinner) v.findViewById(R.id.cauhoibaomat);
		traloiEdt = (EditText) v.findViewById(R.id.traloi_edt);
		dangkyBtn = (Button) v.findViewById(R.id.dangky_btn);

		dangkyBtn.setOnClickListener(this);

		return v;
	}

	private EditText passwordDkEdt;
	private EditText tendangnhapEdt;
	private TextView textView1;
	private Spinner cauhoibaomat;
	private EditText traloiEdt;
	private Button dangkyBtn;

	@Override
	public void onClick(View v) {
		if (v == dangkyBtn) {
			// Handle clicks for dangkyBtn
			if (validate()) {
				String username = tendangnhapEdt.getText().toString();
				String password = passwordDkEdt.getText().toString();
				String answers = traloiEdt.getText().toString();

				ThuVienThoiGian thoigian = new ThuVienThoiGian();

				String question = cauhoibaomat.getSelectedItem().toString();
				NguoiDung nguoiDung = new NguoiDung();
				nguoiDung.setTenDangNhap(username);
				nguoiDung.setMatKhau(password);
				nguoiDung.setCauHoiBaoMat(question);
				nguoiDung.setNgayTao(thoigian.getDateTime());
				nguoiDung.setNgayDangNhap(thoigian.getDateTime());
				nguoiDung.setCauTraLoi(answers);

				QuanLyUser quanLyUser = new QuanLyUser(getActivity());

				if (quanLyUser.dangKy(nguoiDung)) {
					DungPreferences.writeBoolean(getActivity(),
							DungPreferences.LOGGEDIN_SHARED_PREF, true);
					DungPreferences.writeString(getActivity(),
							DungPreferences.USER_NAME, username);

					Intent intent = new Intent(getActivity(),
							HienThiTruyen.class);

					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear
																	// back
																	// stack
					startActivity(intent);
					getActivity().finish();
				}
				else{
					Toast.makeText(getActivity(), "Đăng Ký Thất Bại", Toast.LENGTH_SHORT).show();
				}
			}
		}
	}

	public boolean validate() {
		boolean valid = true;

		String username = tendangnhapEdt.getText().toString();
		String password = passwordDkEdt.getText().toString();
		String answers = traloiEdt.getText().toString();

		String question = cauhoibaomat.getSelectedItem().toString();

		TextView errorText = (TextView) cauhoibaomat.getSelectedView();

		if (containsWhiteSpace(username)) {
			tendangnhapEdt.setError("Tên đăng nhập không chứa khoảng trắng");
			valid = false;
		} else if (username.isEmpty()) {
			tendangnhapEdt.setError("Tên đăng nhập không được bỏ trống");
			valid = false;
		} else if (!username.matches("^[a-z0-9._-]{4,30}$")) {
			tendangnhapEdt
					.setError("Tên đăng nhập cho phép từ 4 đến 30 ký tự và không chứa kí tự đặc biệt");
			valid = false;
		} else {
			tendangnhapEdt.setError(null);
		}

		if (containsWhiteSpace(password)) {
			passwordDkEdt.setError("Mật khẩu không chứa khoảng trắng");
			valid = false;
		} else if (password.isEmpty()) {
			passwordDkEdt.setError("Mật khẩu không được bỏ trống");
			valid = false;
		} else if (!password.matches("^[a-z0-9._-]{4,30}$")) {
			passwordDkEdt
					.setError("Mật khẩu cho phép từ 4 đến 30 ký tự và không chứa kí tự đặc biệt");
			valid = false;
		} else {
			passwordDkEdt.setError(null);
		}

		if (answers.isEmpty()) {
			traloiEdt.setError("Vui lòng nhập câu trả lời");
			valid = false;
		} else {
			traloiEdt.setError(null);
		}

		if (question.isEmpty()) {
			errorText.setError("Vui lòng chọn 1 câu hỏi");
			valid = false;
		} else {
			errorText.setError(null);
		}

		return valid;
	}

	public static boolean containsWhiteSpace(String line) {
		boolean space = false;
		if (line != null) {

			for (int i = 0; i < line.length(); i++) {

				if (line.charAt(i) == ' ') {
					space = true;
				}
			}
		}
		return space;
	}

}
