package test.dangnhap.fragment_user;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import test.dangnhap.DungPreferences;
import test.dangnhap.database.NguoiDung;
import test.dangnhap.database.QuanLyUser;
import test.dangnhap.thuvien.ImageToBytes;
import truyendai.HienThiTruyen;

import com.example.doctruyen.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract.CommonDataKinds.Im;
import android.provider.MediaStore;
import android.provider.MediaStore.Images.Media;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

public class ThongTinNguoiDung extends Fragment implements View.OnClickListener {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.thongtinnguoidung, container,
				false);

		hotenEdt = (EditText) rootView.findViewById(R.id.hoten_edt);
		ngaydangnhap = (EditText) rootView.findViewById(R.id.ngaydangnhap);
		tendangnhap = (EditText) rootView.findViewById(R.id.tendangnhap);
		cauhoibaomat = (EditText) rootView.findViewById(R.id.cauhoibaomat);
		ngaycapnhat = (EditText) rootView.findViewById(R.id.ngaycapnhat);
		ngaytao = (EditText) rootView.findViewById(R.id.ngaytao);
		chinhsuaBtn = (Button) rootView.findViewById(R.id.chinhsua_btn);
		avatar = (ImageView) rootView.findViewById(R.id.avatar);

		chinhsuaBtn.setOnClickListener(this);
		avatar.setOnClickListener(this);

		// lay chi tiet thong tin
		NguoiDung user = new NguoiDung();

		QuanLyUser quanLyUser = new QuanLyUser(getActivity());

		// neu co user name thi show
		String username = DungPreferences.readString(getActivity(),
				DungPreferences.USER_NAME, null);
		user = quanLyUser.ThongTinChiTietTheoTenDangNhap(username);

		hotenEdt.setText(user.getHoTen());
		tendangnhap.setText(user.getTenDangNhap());
		cauhoibaomat.setText(user.getCauHoiBaoMat());
		ngaydangnhap.setText(user.getNgayDangNhap());
		ngaycapnhat.setText(user.getNgayCapNhat());
		ngaytao.setText(user.getNgayTao());
		
		if(user.getHinhAnh() != null){
			ImageToBytes byteHinh = new ImageToBytes();
			avatar.setImageBitmap(byteHinh.loadHinh(user.getHinhAnh()));
		}
		

		return rootView;
	}

	private EditText hotenEdt;
	private EditText tendangnhap;
	private EditText cauhoibaomat;
	private EditText ngaydangnhap;
	private EditText ngaycapnhat;
	private EditText ngaytao;
	private Button chinhsuaBtn;

	private ImageView avatar;
	
	
	@Override
	public void onClick(View v) {
		if (v == chinhsuaBtn) {
			// Handle clicks for chinhsuaBtn
			String name = hotenEdt.getText().toString();
			if(name.matches("^[\\p{L} .'-]+$")){
				hotenEdt.setError(null);
				
				QuanLyUser quanLyUser = new QuanLyUser(getActivity());

				String username = DungPreferences.readString(getActivity(),
						DungPreferences.USER_NAME, null);
				ImageToBytes byteHinh = new ImageToBytes();
				
				quanLyUser.suaHoTen(username, name, byteHinh.ImageViewToByte(avatar));
				Intent intent = new Intent(getActivity(), HienThiTruyen.class);
	            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
	            startActivity(intent);
	            getActivity().finish();
			}
			else {
				hotenEdt.setError("Họ tên chỉ cho phép kí tự thường và dấu cách");
			}
			
			
		}
		if (v == avatar) {

			String names[] = { "Chọn Hình Từ Thư Viện", "Chụp Hình" };
			final AlertDialog.Builder alertDialog = new AlertDialog.Builder(
					getActivity());
			LayoutInflater inflater = getActivity().getLayoutInflater();
			View convertView = (View) inflater.inflate(R.layout.list_camera,
					null);
			alertDialog.setView(convertView);
			alertDialog.setTitle("Cập Nhật Ảnh Đại Diện");
			
			final AlertDialog dialog = alertDialog.create();
			ListView lv = (ListView) convertView.findViewById(R.id.listView1);
			ArrayAdapter<String> adapter = new ArrayAdapter<String>(
					getActivity(), android.R.layout.simple_list_item_1, names);
			lv.setAdapter(adapter);

			lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> adapter, View view,
						int position, long arg) {
					// TODO Auto-generated method stub
					dialog.dismiss();
					if (position == 0) {

						loadImagefromGallery();

					}
					if (position == 1) {
						takePhoto();
					}
				}
			});
			dialog.show();
		}
	}

	// lay hinh tu gallery
	private static final int RESULT_LOAD_IMG = 1;
	String imgDecodableString;

	public void loadImagefromGallery() {
		// Create intent to Open Image applications like Gallery, Google Photos
		Intent galleryIntent = new Intent(Intent.ACTION_PICK,
				android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		// Start the Intent
		startActivityForResult(galleryIntent, RESULT_LOAD_IMG);
	}

	// chup hinh cho avatar
	private static final int TAKE_PHOTO_CODE = 2;

	private void takePhoto() {
		try {
			final Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			intent.putExtra(MediaStore.EXTRA_OUTPUT,
					Uri.fromFile(getTempFile(getActivity())));
			startActivityForResult(intent, TAKE_PHOTO_CODE);
		} catch (Exception e) {
			Toast.makeText(getActivity(),
					"Thiết bị của bạn không hỗ trợ chụp ảnh\n" +e,
					Toast.LENGTH_LONG).show();
		}
		
	}

	private File getTempFile(Context context) {
		// it will return /sdcard/image.tmp
		final File path = new File(Environment.getExternalStorageDirectory(),
				context.getPackageName());
		if (!path.exists()) {
			path.mkdir();
		}
		return new File(path, "image.tmp");
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Activity.RESULT_OK) {
			switch (requestCode) {
			case TAKE_PHOTO_CODE:
				final File file = getTempFile(getActivity());
				try {

					Bitmap captureBmp = Media.getBitmap(getActivity()
							.getContentResolver(), Uri.fromFile(file));

					// do whatever you want with the bitmap (Resize, Rename,
					// Add
					// To Gallery, etc)
					if (captureBmp != null) {
						avatar.setImageBitmap(captureBmp);
					} else {
						Toast.makeText(getActivity(),
								"Hình của bạn chưa được chụp",
								Toast.LENGTH_LONG).show();
					}
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;

			case RESULT_LOAD_IMG:
				try {
					// When an Image is picked
					if (null != data) {
						// Get the Image from data

						Uri selectedImage = data.getData();
						String[] filePathColumn = { MediaStore.Images.Media.DATA };

						// Get the cursor
						Cursor cursor = getActivity().getContentResolver()
								.query(selectedImage, filePathColumn, null,
										null, null);
						// Move to first row
						cursor.moveToFirst();

						int columnIndex = cursor
								.getColumnIndex(filePathColumn[0]);
						imgDecodableString = cursor.getString(columnIndex);
						cursor.close();

						// Set the Image in ImageView after decoding the String
						avatar.setImageBitmap(BitmapFactory
								.decodeFile(imgDecodableString));

					} else {
						Toast.makeText(getActivity(),
								"Bạn chưa lấy hình nào từ thư viện",
								Toast.LENGTH_LONG).show();
					}
				} catch (Exception e) {
					Toast.makeText(getActivity(),
							"Lỗi xảy ra khi lấy hình từ thư viện",
							Toast.LENGTH_LONG).show();
				}
				break;
			}
		}

	}
}