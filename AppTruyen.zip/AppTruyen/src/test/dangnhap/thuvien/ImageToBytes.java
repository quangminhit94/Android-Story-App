package test.dangnhap.thuvien;

import java.io.ByteArrayOutputStream;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.widget.ImageView;

public class ImageToBytes {
	public byte[] ImageViewToByte(ImageView img){
		BitmapDrawable drawable = (BitmapDrawable) img.getDrawable();
		Bitmap bmp = drawable.getBitmap();
		
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
		byte[] byteArray = stream.toByteArray();
		return byteArray;
	}

	public Bitmap loadHinh(byte[] hinh){
		Bitmap bitmap = BitmapFactory.decodeByteArray(hinh, 0, hinh.length);
		return bitmap;
	}
}
