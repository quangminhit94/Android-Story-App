package truyencuoi;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.example.doctruyen.R;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingActivity;

import DatabaseAndAdapter.TruyenCuoiAdapter;
import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import menutruyen.MenuAdapter;
import nl.siegmann.epublib.domain.Book;
import nl.siegmann.epublib.domain.TOCReference;
import nl.siegmann.epublib.epub.EpubReader;
import test.dangnhap.DangNhapActivity;
import test.dangnhap.DashboardNguoiDung;
import test.dangnhap.DungPreferences;
import truyendai.HienThiTruyen;
import truyenngan.MainTruyenNgan;


public class MainTruyenCuoi extends SlidingActivity {
	private ArrayList<RowData> contentDetails;
	public static final String BOOK_NAME = "truyencuoi.epub";
	ArrayList<String> simpletitle=new ArrayList<String>();
	EditText ed;
    ListView lv;
	TruyenCuoiAdapter adapter;
	private ImageView anhDaiDien;
	private TextView hoTen;
	private TextView tenDangNhap;
	private LinearLayout phanDangNhap;
	private Button dangnhap;
	String username;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.maintruyencuoi);
		  lv = (ListView)findViewById(R.id.listView1);
			ed = (EditText)findViewById(R.id.editText1);
			SlidingMenu menu = new SlidingMenu(this);
			setBehindContentView(R.layout.fragment_navigation);
			getSlidingMenu().setBehindOffset(200);
			getSlidingMenu().setMode(SlidingMenu.LEFT);
			getSlidingMenu().setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
			getSlidingMenu().setFadeDegree(0.75f);
			getActionBar().setDisplayHomeAsUpEnabled(true);
			ListView lv1=(ListView) findViewById(R.id.listViewcc);
			lv1.setAdapter(new MenuAdapter(this));
			lv1.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					switch (position) {
					case 0:
						Intent intent = new Intent(MainTruyenCuoi.this, HienThiTruyen.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
	                    startActivity(intent);
						break;
					case 1:

						Intent i = new Intent(MainTruyenCuoi.this, MainTruyenCuoi.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
	                    startActivity(i);
						break;
					case 2:
						Intent intent1 = new Intent(MainTruyenCuoi.this, MainTruyenNgan.class);
						intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
	                    startActivity(intent1);
						break;
					case 3:
						Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + "gopythemtruyen@gmail.com"));
						intent2.putExtra(Intent.EXTRA_SUBJECT, "Góp Ý Thêm Truyện ");
						intent2.putExtra(Intent.EXTRA_TEXT, "Tên Truyện : Ý kiến đóng góp : ");
	                    startActivity(intent2);
						break;
					case 4:
						Intent homeIntent = new Intent(Intent.ACTION_MAIN);
					    homeIntent.addCategory( Intent.CATEGORY_HOME );
					    homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);  
					    startActivity(homeIntent); 
						break;
						
					}
					
				}
			});
		
		contentDetails = new ArrayList<RowData>();
		AssetManager assetManager = getAssets();
		try {
			InputStream epubInputStream = assetManager.open(BOOK_NAME);
			Book book = (new EpubReader()).readEpub(epubInputStream);
			logContentsTable(book.getTableOfContents().getTocReferences(), 0);
		} catch (IOException e) {
			Log.e("epublib", e.getMessage());
		}
		for(int i=0;i<contentDetails.size();i++)
		{
			simpletitle.add(contentDetails.get(i).getTitle().trim());
		}
	adapter=new TruyenCuoiAdapter(this,simpletitle);
		lv.setAdapter(adapter);
   lv.setOnItemClickListener(new OnItemClickListener() {

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub
		RowData rowData=contentDetails.get(position);
		try {
			String noidungchuong=new String(rowData.getResource().getData());
			Intent i=new Intent(MainTruyenCuoi.this, ChuongActivity.class);
			i.putExtra("display", noidungchuong);
			startActivity(i);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
});
 
	ed.addTextChangedListener(new TextWatcher() {
		
		
		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
			
       	 MainTruyenCuoi.this. adapter.getFilter().filter(s);			
		}
		
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void afterTextChanged(Editable s) {
			
			
		}
	});
	}
	private void logContentsTable(List<TOCReference> tocReferences, int depth) {
		if (tocReferences == null) {
			return;
		}
		for (TOCReference tocReference : tocReferences) {
			StringBuilder tocString = new StringBuilder();
			for (int i = 0; i < depth; i++) {
				tocString.append("\t");
			}
			tocString.append(tocReference.getTitle());
			RowData row = new RowData();
			row.setTitle(tocString.toString());
			row.setResource(tocReference.getResource());
			contentDetails.add(row);
			logContentsTable(tocReference.getChildren(), depth + 1);
		}
		anhDaiDien = (ImageView) findViewById(R.id.anh_dai_dien);
		hoTen = (TextView) findViewById(R.id.ho_ten);
		tenDangNhap = (TextView) findViewById(R.id.ten_dang_nhap);
		dangnhap = (Button) findViewById(R.id.dang_nhap);
		phanDangNhap = (LinearLayout) findViewById(R.id.phan_dang_nhap);
		username = "";
		username = DungPreferences.readString(this, DungPreferences.USER_NAME, null);

		if (username != null) {
			Toast.makeText(MainTruyenCuoi.this, "Xin Chào " + username, Toast.LENGTH_LONG).show();
			dangnhap.setVisibility(View.GONE);
			phanDangNhap.setVisibility(View.VISIBLE);
			tenDangNhap.setText(username);
		} else {
			dangnhap.setVisibility(View.VISIBLE);
			phanDangNhap.setVisibility(View.GONE);
		}
		dangnhap.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {

				dangnhap();

			}
		});
		
		phanDangNhap.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainTruyenCuoi.this, DashboardNguoiDung.class);
				intent.putExtra("username", username); 
				
				startActivity(intent);
			}
		});
		
	}
		
	public void dangnhap() {
		Intent intent = new Intent(this, DangNhapActivity.class);
		startActivityForResult(intent, 1);// Activity is started with
											// requestCode 2
	}

	
	
	

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == android.R.id.home) {
			toggle();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
