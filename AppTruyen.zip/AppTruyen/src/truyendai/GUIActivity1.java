package truyendai;

import com.example.doctruyen.R;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import truyencuoi.MainTruyenCuoi;
import truyenngan.MainTruyenNgan;

public class GUIActivity1 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gui1);
	}
   public void truyendai(View v){
	   Intent intent = new Intent(this, HienThiTruyen.class);
	   startActivity(intent);
   }
   public void truyencuoi(View v){
	   Intent intent = new Intent(this, MainTruyenCuoi.class);
	   startActivity(intent);
   }
   public void mail(View v){
	   Intent intent = new Intent (Intent.ACTION_VIEW , Uri.parse("mailto:" + "gopythemtruyen@gmail.com"));
	   intent.putExtra(Intent.EXTRA_SUBJECT, "Góp Ý Thêm Truyện ");
	   intent.putExtra(Intent.EXTRA_TEXT, "Tên Truyện : Ý kiến đóng góp : ");
	   startActivity(intent);
   }
   public void truyenngan(View v){
	   Intent intent = new Intent(this, MainTruyenNgan.class);
	   startActivity(intent);
   }
  
	

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
