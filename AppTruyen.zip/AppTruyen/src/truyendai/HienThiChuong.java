package truyendai;

import java.util.ArrayList;

import com.example.doctruyen.R;

import DatabaseAndAdapter.Chuong;
import DatabaseAndAdapter.ChuongAdapter;
import DatabaseAndAdapter.DBHelper;
import DatabaseAndAdapter.SQLDatabaseSource;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class HienThiChuong extends Activity {
 ListView lv,lv1;
 DBHelper helper;
 ArrayList<Chuong> list = new ArrayList<Chuong>();
ChuongAdapter adapter;
String tentruyen,tenchuong;
ArrayList<String> listchuong=new ArrayList<String>();
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hien_thi_chuong);
		SQLDatabaseSource db;
		db = new SQLDatabaseSource(this);
		Intent intent=getIntent();
		tentruyen=intent.getStringExtra("tentruyen");
		lv = (ListView)findViewById(R.id.listView2);
		adapter = new ChuongAdapter(this, list);
		lv.setAdapter(adapter);
        lv.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				tenchuong = list.get(position).chuong;
				Intent intent = new Intent(HienThiChuong.this, HienThiNoiDung.class);
				intent.putExtra("noidung", tenchuong);
				intent.putExtra("stt", position);
				intent.putStringArrayListExtra("mangchuong", listchuong);
				startActivity(intent);
			}
		});
		updateload();
	}
	public void updateload(){
		list.clear();
		helper = new DBHelper(this);
		SQLiteDatabase db = helper.openDatabase();
		Cursor c = db.rawQuery("Select tenchuong from chuongtruyen where tentruyen=?",new String[]{tentruyen});
		while(c.moveToNext()){
			 Chuong ch = new Chuong();
			 ch.chuong = c.getString(0);
			 list.add(ch);
			 listchuong.add(c.getString(0));
		}
		db.close();
		lv.setAdapter(new ChuongAdapter(this, list));
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == android.R.id.home) {
		
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
