
package truyendai;

import java.util.ArrayList;

import com.example.doctruyen.R;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingActivity;

import DatabaseAndAdapter.Chuong;
import DatabaseAndAdapter.DBHelper;
import DatabaseAndAdapter.SQLDatabaseSource;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import menutruyen.MenuAdapter;
import test.dangnhap.DangNhapActivity;
import test.dangnhap.DashboardNguoiDung;
import test.dangnhap.DungPreferences;
import truyencuoi.MainTruyenCuoi;
import truyenngan.MainTruyenNgan;

public class HienThiNoiDung extends SlidingActivity {
	DBHelper helper;
	TextView txt,txt1;
	String noidung;
	ArrayList<String> mangchuong=new ArrayList<String>();
	 ArrayList<Chuong> list = new ArrayList<Chuong>();
	Button btnback,btnnext;
	int current;
	ImageView img;
	ListView lv1;
	String tenchuong;
	String tentruyen;
	private ImageView anhDaiDien;
	private TextView hoTen;
	private TextView tenDangNhap;
	private LinearLayout phanDangNhap;
	private Button dangnhap;
	String username;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hienthi_noidung);
		SQLDatabaseSource db;
		db = new SQLDatabaseSource(this);
		Intent intent=getIntent();
		noidung=intent.getStringExtra("noidung");
		current=intent.getIntExtra("stt", 0);
		mangchuong=intent.getStringArrayListExtra("mangchuong");
		
		SlidingMenu menu = new SlidingMenu(this);
		setBehindContentView(R.layout.fragment_navigation);
		getSlidingMenu().setBehindOffset(200);
		getSlidingMenu().setMode(SlidingMenu.LEFT);
		getSlidingMenu().setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
		getSlidingMenu().setFadeDegree(0.75f);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		btnback = (Button)findViewById(R.id.button1);
		btnnext = (Button)findViewById(R.id.button2);
		img = (ImageView)findViewById(R.id.imageView1);
		txt1 = (TextView)findViewById(R.id.txtTitle);
		txt= (TextView)findViewById(R.id.textViewNoiDung);
		txt.setMovementMethod(new ScrollingMovementMethod());
		
		lv1=(ListView) findViewById(R.id.listViewcc);
		lv1.setAdapter(new MenuAdapter(this));
		
		lv1.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				switch (position) {
				case 0:
					Intent intent = new Intent(HienThiNoiDung.this, HienThiTruyen.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
                    startActivity(intent);
					break;
				case 1:

					Intent i = new Intent(HienThiNoiDung.this, MainTruyenCuoi.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
                    startActivity(i);
					break;
				case 2:
					Intent intent1 = new Intent(HienThiNoiDung.this, MainTruyenNgan.class);
					intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
                    startActivity(intent1);
					break;
				case 3:
					Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + "gopythemtruyen@gmail.com"));
					intent2.putExtra(Intent.EXTRA_SUBJECT, "Góp Ý Thêm Truyện ");
					intent2.putExtra(Intent.EXTRA_TEXT, "Tên Truyện : Ý kiến đóng góp : ");

					intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
                    startActivity(intent2);
					break;
				case 4:
					Intent homeIntent = new Intent(Intent.ACTION_MAIN);
				    homeIntent.addCategory( Intent.CATEGORY_HOME );
				    homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);  
				    startActivity(homeIntent); 
					break;
				}
			}
		});
		shownd();
		anhDaiDien = (ImageView) findViewById(R.id.anh_dai_dien);
		hoTen = (TextView) findViewById(R.id.ho_ten);
		tenDangNhap = (TextView) findViewById(R.id.ten_dang_nhap);
		dangnhap = (Button) findViewById(R.id.dang_nhap);
		phanDangNhap = (LinearLayout) findViewById(R.id.phan_dang_nhap);
		username = "";
		username = DungPreferences.readString(this, DungPreferences.USER_NAME, null);

		if (username != null) {
			
			dangnhap.setVisibility(View.GONE);
			phanDangNhap.setVisibility(View.VISIBLE);
			tenDangNhap.setText(username);
		} else {
			dangnhap.setVisibility(View.VISIBLE);
			phanDangNhap.setVisibility(View.GONE);
		}
		dangnhap.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {

				dangnhap();

			}
		});
		
		phanDangNhap.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HienThiNoiDung.this, DashboardNguoiDung.class);
				intent.putExtra("username", username); 
				
				startActivity(intent);
			}
		});
		txt1.setText(mangchuong.get(current)+"");
	}
		
	public void dangnhap() {
		Intent intent = new Intent(this, DangNhapActivity.class);
		startActivityForResult(intent, 1);// Activity is started with
											// requestCode 2
	}
	public void next(View v){
		if(current>=mangchuong.size()-1){
			 Toast.makeText(this, "Bạn đang ở chương cuối cùng", Toast.LENGTH_SHORT).show();
		}else{
			current+=1;
			txt1.setText(mangchuong.get(current)+"");
			noidung=mangchuong.get(current);
		}
		shownd();
	}
     public void back(View v){
    	 if(current ==0){
    		 Toast.makeText(this, "Bạn đang ở chương đầu tiên", Toast.LENGTH_SHORT).show();
    	 }else{
    		 current-=1;
    		 txt1.setText(mangchuong.get(current)+"");
 		noidung=mangchuong.get(current);
    	 }
 	shownd();
	}
     public void shownd(){
    	
  	    helper = new DBHelper(this);
  		SQLiteDatabase db = helper.openDatabase();
  		Cursor c = db.rawQuery("Select noidung from chuongtruyen where tenchuong=?", new String[]{noidung});
  		while(c.moveToNext()){
  			txt.setText("Chúc các bạn xem truyện vui vẻ ^^! Theo dõi thêm nhiều truyện hay mỗi tuần nhé♥"
  		+"\n "+"\n"+"                      ---------------------------"+" \n "+c.getString(0));
  		}
  		db.close();
     }
  
    
     @Override
 	public boolean onOptionsItemSelected(MenuItem item) {
 		// Handle action bar item clicks here. The action bar will
 		// automatically handle clicks on the Home/Up button, so long
 		// as you specify a parent activity in AndroidManifest.xml.
 		int id = item.getItemId();
 		if (id == android.R.id.home) {
 			toggle();
 			return true;
 		}
 		return super.onOptionsItemSelected(item);
 	}
}
