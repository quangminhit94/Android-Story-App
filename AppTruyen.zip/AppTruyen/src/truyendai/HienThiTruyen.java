package truyendai;

import java.util.ArrayList;

import com.example.doctruyen.R;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingActivity;

import DatabaseAndAdapter.DBHelper;
import DatabaseAndAdapter.SQLDatabaseSource;
import DatabaseAndAdapter.Truyen;
import DatabaseAndAdapter.TruyenAdapter;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import menutruyen.MenuAdapter;
import test.dangnhap.DangNhapActivity;
import test.dangnhap.DashboardNguoiDung;
import test.dangnhap.DungPreferences;
import test.dangnhap.database.NguoiDung;
import test.dangnhap.database.QuanLyUser;
import test.dangnhap.thuvien.ImageToBytes;
import truyencuoi.MainTruyenCuoi;
import truyenngan.MainTruyenNgan;

public class HienThiTruyen extends SlidingActivity {
	private EditText edsearch;
	private TextView textViewTheloai;
	CheckBox cb1, cb2, cb3,cb4;

	private ListView lv1;
	private ImageView anhDaiDien;
	private TextView hoTen;
	private TextView tenDangNhap;
	private LinearLayout phanDangNhap;
	private Button dangnhap;
	String username;
	DBHelper helper;
	ListView lv;
	ArrayList<Truyen> list = new ArrayList<Truyen>();
	TruyenAdapter adapter;
	private String phieuluu = "", hocduong = "", tinhcam = "";
	Truyen tr = new Truyen();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hienthitruyen2);
		SQLDatabaseSource db;
		db = new SQLDatabaseSource(this);

		SlidingMenu menu = new SlidingMenu(this);
		setBehindContentView(R.layout.fragment_navigation);
		getSlidingMenu().setBehindOffset(200);
		getSlidingMenu().setMode(SlidingMenu.LEFT);
		getSlidingMenu().setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
		getSlidingMenu().setFadeDegree(0.75f);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		ListView lv1 = (ListView) findViewById(R.id.listViewcc);
		edsearch = (EditText) findViewById(R.id.editText1);
		textViewTheloai = (TextView) findViewById(R.id.textViewTheloai);
		cb1 = (CheckBox) findViewById(R.id.checkBox1);
		cb2 = (CheckBox) findViewById(R.id.checkBox2);
		cb3 = (CheckBox) findViewById(R.id.checkBox3);
		cb4 = (CheckBox)findViewById(R.id.checkBox4);
		lv = (ListView) findViewById(R.id.listView1);

		adapter = new TruyenAdapter(this, list);
		lv.setAdapter(adapter);

		edsearch.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				String nhap = edsearch.getText().toString().toLowerCase();
				list.clear();
				helper = new DBHelper(HienThiTruyen.this);
				SQLiteDatabase db = helper.openDatabase();
				Cursor c = db.rawQuery("Select * from truyen where tentruyen LIKE '%" + nhap + "%'", null);
				while (c.moveToNext()) {
					Truyen tr = new Truyen();
					tr.tentruyen = c.getString(0);
					tr.theloai = c.getString(1);
					list.add(tr);
				}
				adapter.notifyDataSetChanged();
			}
		});
		lv.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				helper = new DBHelper(HienThiTruyen.this);
				SQLiteDatabase db = helper.openDatabase();
				Cursor c = db.rawQuery("select tentruyen from truyen where tentruyen=?",
						new String[] { (list.get(position).tentruyen) });
				String tentruyen = null;
				while (c.moveToNext()) {
					tentruyen = c.getString(0);
				}
				Intent intent = new Intent(HienThiTruyen.this, HienThiChuong.class);
				intent.putExtra("tentruyen", tentruyen);
				startActivity(intent);
			}
		});
		upload();
		
		cb1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (cb1.isChecked()) {
					phieuluu = cb1.getText().toString();
					check(phieuluu, hocduong, tinhcam);
				} else {
					phieuluu = "";
					if (phieuluu.contentEquals("") && hocduong.equals("") && tinhcam.equals("")) {
						upload();
					}else{
						check(phieuluu, hocduong, tinhcam);
					}
				}
				
			}
		});

		cb2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (cb2.isChecked()) {
					hocduong = cb2.getText().toString();
					check(phieuluu, hocduong, tinhcam);
				}else {
					hocduong = "";
					if (phieuluu.contentEquals("") && hocduong.equals("") && tinhcam.equals("")) {
						upload();
					}else{
						check(phieuluu, hocduong, tinhcam);
					}
				}
				
				
			}
		});

		cb3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (cb3.isChecked()) {
					tinhcam = cb3.getText().toString();
					check(phieuluu, hocduong, tinhcam);
				} else {
					tinhcam = "";
					if (phieuluu.contentEquals("") && hocduong.equals("") && tinhcam.equals("")) {
						upload();
					}else{
						check(phieuluu, hocduong, tinhcam);
					}
				}
				
				
			}
		});
       cb4.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			if (cb4.isChecked()) {
				upload();
			}
		}
	});
		lv1 = (ListView) findViewById(R.id.listViewcc);
		lv1.setAdapter(new MenuAdapter(this));
		lv1.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				switch (position) {
				case 0:
					Intent intent = new Intent(HienThiTruyen.this, HienThiTruyen.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
                    startActivity(intent);
					break;
				case 1:

					Intent i = new Intent(HienThiTruyen.this, MainTruyenCuoi.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
                    startActivity(i);
					break;
				case 2:
					Intent intent1 = new Intent(HienThiTruyen.this, MainTruyenNgan.class);
					intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
                    startActivity(intent1);
					break;
				case 3:
					Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + "gopythemtruyen@gmail.com"));
					intent2.putExtra(Intent.EXTRA_SUBJECT, "Góp Ý Thêm Truyện ");
					intent2.putExtra(Intent.EXTRA_TEXT, "Tên Truyện : Ý kiến đóng góp : ");

					intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// clear back stack
                    startActivity(intent2);
					break;
				case 4:
					Intent homeIntent = new Intent(Intent.ACTION_MAIN);
				    homeIntent.addCategory( Intent.CATEGORY_HOME );
				    homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);  
				    startActivity(homeIntent); 
					break;
				}

			}
		});

		//day
		anhDaiDien = (ImageView) findViewById(R.id.anh_dai_dien);
		hoTen = (TextView) findViewById(R.id.ho_ten);
		tenDangNhap = (TextView) findViewById(R.id.ten_dang_nhap);
		dangnhap = (Button) findViewById(R.id.dang_nhap);
		phanDangNhap = (LinearLayout) findViewById(R.id.phan_dang_nhap);
		username = "";

		// neu co user name thi show
		username = DungPreferences.readString(this, DungPreferences.USER_NAME,
				null);
		

		if (username != null) {
			NguoiDung user = new NguoiDung();

			QuanLyUser quanLyUser = new QuanLyUser(this);
			user = quanLyUser.ThongTinChiTietTheoTenDangNhap(username);
			
			Toast.makeText(HienThiTruyen.this,
					"Xin Chào " + username, Toast.LENGTH_LONG).show();
			dangnhap.setVisibility(View.GONE);
			phanDangNhap.setVisibility(View.VISIBLE);
			tenDangNhap.setText(username);
			if(user.getHoTen() != null){
				hoTen.setText(user.getHoTen());	
			}
			else{
				
				hoTen.setText("Xin Chào ");
				
			}
			try {
				if(user.getHinhAnh() != null){
					ImageToBytes byteHinh = new ImageToBytes();
					anhDaiDien.setImageBitmap(byteHinh.loadHinh(user.getHinhAnh()));
				}
			} catch (Exception e) {
				Toast.makeText(this, "Lỗi ảnh đại diện: "+e,
						Toast.LENGTH_LONG).show();
			}
			
			
		} else {
			dangnhap.setVisibility(View.VISIBLE);
			phanDangNhap.setVisibility(View.GONE);
		}

		dangnhap.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {

				dangnhap();

			}
		});

		phanDangNhap.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HienThiTruyen.this,
						DashboardNguoiDung.class);

				startActivity(intent);
			}
		});

	}

	public void dangnhap() {
		Intent intent = new Intent(this, DangNhapActivity.class);
		startActivity(intent);
	}

	

	public void tim() {
		

	}

	public void check(String phieuluu, String hocduong, String tinhcam) {
		list.clear();
		helper = new DBHelper(this);
		SQLiteDatabase db = helper.openDatabase();
		Cursor c = db.rawQuery("Select tentruyen,theloai from truyen where theloai=? or theloai=? or theloai=?",
				new String[] { phieuluu, hocduong, tinhcam });
		while (c.moveToNext()) {
			Truyen tr = new Truyen();
			tr.tentruyen = c.getString(0);
			tr.theloai = c.getString(1);
			list.add(tr);

		}
		db.close();
		adapter.notifyDataSetChanged();
	}

	public void upload() {
		list.clear();
		helper = new DBHelper(this);
		SQLiteDatabase db = helper.openDatabase();
		String sql = "Select tentruyen,theloai from truyen";
		Cursor c = db.rawQuery(sql, null);
		while (c.moveToNext()) {
			Truyen tr = new Truyen();
			tr.tentruyen = c.getString(0);
			tr.theloai = c.getString(1);
			list.add(tr);
		}
		db.close();
		adapter.notifyDataSetChanged();
	}

	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == android.R.id.home) {
			toggle();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}