package truyenngan;

import com.example.doctruyen.R;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class ChuongTruyenNgan extends Activity {
	WebView webview;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.chuongtruyencuoi);
		
		 webview = (WebView)findViewById(R.id.webView1);
			
		 String displayString = getIntent().getExtras().getString("display");
		 if(displayString != null)
		 {
		     WebSettings settings = webview.getSettings();
		     settings.setDefaultTextEncodingName("utf-8");
		     settings.setDefaultFontSize(15);
		    //int fontSize = webview.getSettings().getDefaultFontSize();
		     webview.loadDataWithBaseURL(null, displayString, "text/html", "utf-8", null);
		     webview.setVerticalScrollBarEnabled(true);
		 }
	}

	

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
