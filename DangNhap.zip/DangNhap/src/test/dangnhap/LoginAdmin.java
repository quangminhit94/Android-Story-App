package test.dangnhap;

import info.androidhive.tabsswipe.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class LoginAdmin extends Activity implements OnClickListener{
	private EditText usernameEdt;
	private EditText passwordEdt;
	private Button dangnhapBtn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_admin);
		findViews();
	}
	
	private void findViews() {
		usernameEdt = (EditText)findViewById( R.id.username_edt );
		passwordEdt = (EditText)findViewById( R.id.password_edt );
		dangnhapBtn = (Button)findViewById( R.id.dangnhap_btn );
		
		dangnhapBtn.setOnClickListener( this );
	}

	
	@Override
	public void onClick(View v) {
		if ( v == dangnhapBtn ) {
			// Handle clicks for dangnhapBtn
		}
	}

}
