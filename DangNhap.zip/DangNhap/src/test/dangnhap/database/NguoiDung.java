package test.dangnhap.database;

import java.util.List;

public class NguoiDung {
	
	private String NguoiDungID;
	private String HoTen;
	private String TenDangNhap;
	private String MatKhau;
	private String CauHoiBaoMat;
	private String CauTraLoi;
	private String NgayTao;
	private String NgayCapNhat;
	private String NgayDangNhap;
	private String Role;
	
	
	public String getNguoiDungID() {
		return NguoiDungID;
	}
	public String getHoTen() {
		return HoTen;
	}
	public String getTenDangNhap() {
		return TenDangNhap;
	}
	public String getCauHoiBaoMat() {
		return CauHoiBaoMat;
	}
	public String getCauTraLoi() {
		return CauTraLoi;
	}
	
	public String getMatKhau() {
		return MatKhau;
	}
	public String getNgayTao() {
		return NgayTao;
	}
	public String getNgayCapNhat() {
		return NgayCapNhat;
	}
	public String getNgayDangNhap() {
		return NgayDangNhap;
	}
	
	public String getRole() {
		return Role;
	}

	public void setNguoiDungID(String nguoiDungID) {
		NguoiDungID = nguoiDungID;
	}
	public void setHoTen(String hoTen) {
		HoTen = hoTen;
	}
	public void setTenDangNhap(String tenDangNhap) {
		TenDangNhap = tenDangNhap;
	}
	public void setCauHoiBaoMat(String cauHoiBaoMat) {
		CauHoiBaoMat = cauHoiBaoMat;
	}
	public void setCauTraLoi(String cauTraLoi) {
		CauTraLoi = cauTraLoi;
	}
	public void setMatKhau(String matKhau) {
		MatKhau = matKhau;
	}
	public void setNgayTao(String ngayTao) {
		NgayTao = ngayTao;
	}
	public void setNgayCapNhat(String ngayCapNhat) {
		NgayCapNhat = ngayCapNhat;
	}
	public void setNgayDangNhap(String ngayDangNhap) {
		NgayDangNhap = ngayDangNhap;
	}
	public void setRole(String role) {
		Role = role;
	}
	
}
