package test.dangnhap.database;

import java.util.HashMap;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class QuanLyAdmin {
	SQLiteDatabase db;
	Activity activity;

	public QuanLyAdmin(Activity activity) {
		this.activity = activity;
		db = new UserHelper(activity).getWritableDatabase();
	}

	public void ThemAdmin(NguoiDung nguoidung) {
		ContentValues values = new ContentValues();
		// values.put(KEY_MAPN_PRIMARY, 1);
		values.put("NguoiDungID", nguoidung.getHoTen());
		values.put("HoTen", nguoidung.getHoTen());
		values.put("TenDangNhap", nguoidung.getTenDangNhap());
		values.put("MatKhau", nguoidung.getMatKhau());
		values.put("CauHoi", nguoidung.getCauHoiBaoMat());
		values.put("TraLoi", nguoidung.getCauTraLoi());
		values.put("NgayTao", nguoidung.getNgayTao());
		values.put("NgayCapNhat", nguoidung.getNgayCapNhat());
		values.put("DangNhapLanCuoi", nguoidung.getNgayDangNhap());
		values.put("Role", 1);
		// insert the row
		db.insert("nguoidung", null, values);
		db.close(); // Closing database connection
	}

	public String dangNhap(String username) {
		Cursor cursor = db.rawQuery("SELECT * FROM nguoidung WHERE TenDangNhap=? AND Role=1"
				, new String[] { username});
		if (cursor.getCount() < 1) {
			cursor.close();
			return "Khong co";
		}
		else{
			cursor.moveToFirst();
			String password = cursor.getString(cursor.getColumnIndex("MatKhau"));
			cursor.close();
			return password;
		}
		
	}
	/**
	 * Getting user data from database
	 * */
	public HashMap<String, String> getUserDetails() {
		HashMap<String, String> user = new HashMap<String, String>();
		String selectQuery = "SELECT  * FROM nguoidung";

		db = new UserHelper(activity).getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// Move to first row
		cursor.moveToFirst();
		if (cursor.getCount() > 0) {
			user.put("fname", cursor.getString(1));
			user.put("lname", cursor.getString(2));
			user.put("email", cursor.getString(3));
			user.put("uname", cursor.getString(4));
			user.put("uid", cursor.getString(5));
			user.put("created_at", cursor.getString(6));
		}
		cursor.close();
		db.close();
		// return user
		return user;
	}

	/**
	 * Getting user login status return true if rows are there in table
	 * */
	public int getRowCount() {
		String countQuery = "SELECT  * FROM nguoidung";
		db = new UserHelper(activity).getReadableDatabase();
		Cursor cursor = db.rawQuery(countQuery, null);
		int rowCount = cursor.getCount();
		db.close();
		cursor.close();

		// return row count
		return rowCount;
	}
}
