package test.dangnhap.database;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import test.dangnhap.thuvien.ThuVienThoiGian;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class UserHelper extends SQLiteOpenHelper {
	
	public UserHelper(Context context) {
		super(context, "truyen.sqlite", null, 21);
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		//db.execSQL("CREATE TABLE nguoidung(NguoiDungID INTEGER PRIMARY KEY autoincrement, HoTen text, TenDangNhap text UNIQUE, MatKhau text, TraLoi text, NgayTao DATETIME DEFAULT CURRENT_TIMESTAMP,NgayCapNhat DATETIME , DangNhapLanCuoi DATETIME, Role INTEGER DEFAULT 0)");
		
		db.execSQL("CREATE TABLE nguoidung(NguoiDungID integer PRIMARY KEY, HoTen text, TenDangNhap text UNIQUE, MatKhau text, CauHoi text, TraLoi text, NgayTao DATETIME DEFAULT CURRENT_TIMESTAMP,NgayCapNhat DATETIME DEFAULT CURRENT_TIMESTAMP , DangNhapLanCuoi DATETIME, Role INTEGER DEFAULT 0, HinhAnh BLOB)");
		//db.execSQL("CREATE UNIQUE INDEX userunique ON nguoidung(TenDangNhap)");
		db.execSQL("INSERT INTO nguoidung VALUES( NULL,'', 'admin' , 'admin','Ban sinh o dau', 'LongKhanh', datetime(), datetime(), datetime(), 1)");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS nguoidung");
		this.onCreate(db);
	}

}