package test.dangnhap.fragment_user;

import test.dangnhap.DashboardNguoiDung;
import test.dangnhap.database.NguoiDung;
import test.dangnhap.database.QuanLyUser;
import info.androidhive.tabsswipe.R;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DoiMatKhau extends Fragment implements OnClickListener {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.doimatkhau, container, false);
		matkhaucuEdt = (EditText) rootView.findViewById(R.id.matkhaucu_edt);
		matkhaumoiEdt = (EditText) rootView.findViewById(R.id.matkhaumoi_edt);
		doimatkhauBtn = (Button) rootView.findViewById(R.id.doimatkhau_btn);
		traloiEdt = (EditText) rootView.findViewById(R.id.traloi_edt);

		doimatkhauBtn.setOnClickListener(this);
		return rootView;
	}

	private EditText matkhaucuEdt;
	private EditText matkhaumoiEdt;
	private Button doimatkhauBtn;
	private EditText traloiEdt;

	@Override
	public void onClick(View v) {
		if (v == doimatkhauBtn) {
			if(validate()){
				String newpass = matkhaumoiEdt.getText().toString();
				// lay chi tiet thong tin
				QuanLyUser quanLyUser = new QuanLyUser(getActivity());
				
				Intent intent = getActivity().getIntent();
				Bundle b = intent.getExtras();
				if (b != null) {
				String username = (String) b.get("username");
				quanLyUser.doiMatKhau(username, newpass);
				Toast.makeText(getActivity(), "Đổi mật khẩu thành công", Toast.LENGTH_LONG).show();
				}
				
			}
			else{
				Toast.makeText(getActivity(), "Đổi mật khẩu thất bại", Toast.LENGTH_LONG).show();
			}
		}
	}

	// Bẫy lỗi bỏ trống
	public boolean validate() {
		boolean valid = true;

		String oldpass = matkhaucuEdt.getText().toString();
		String answer = traloiEdt.getText().toString();
		String newpass = matkhaumoiEdt.getText().toString();

		// lay chi tiet thong tin
		NguoiDung user = new NguoiDung();
		QuanLyUser quanLyUser = new QuanLyUser(getActivity());
		
		Intent intent = getActivity().getIntent();
		Bundle b = intent.getExtras();

		if (oldpass.isEmpty() || oldpass.length() < 5 || oldpass.length() > 30) {
			matkhaucuEdt.setError("Mật khẩu cho phép từ 4 đến 30 ký tự ");
			valid = false;
		} else {
			matkhaucuEdt.setError(null);
		}

		if (newpass.isEmpty() || newpass.length() < 5 || newpass.length() > 30) {
			matkhaumoiEdt.setError("Mật khẩu mới cho phép từ 4 đến 30 ký tự");
			valid = false;
		} else {
			matkhaumoiEdt.setError(null);
		}

		if (b != null) {
			String username = (String) b.get("username");
			user = quanLyUser.ThongTinChiTietTheoTenDangNhap(username);

			if (!oldpass.equals(user.getMatKhau())) {
				matkhaucuEdt.setError("Sai Mật Khẩu");
				valid = false;
			} else {
				matkhaucuEdt.setError(null);
			}
			if (!answer.equals(user.getCauTraLoi())) {
				traloiEdt.setError("Sai Câu Trả Lời Bảo Mật");
				valid = false;
			}
			else{
				traloiEdt.setError(null);
			}
		}

		return valid;
	}

}