package test.dangnhap.fragment_user;

import java.util.HashMap;

import test.dangnhap.database.NguoiDung;
import test.dangnhap.database.QuanLyUser;

import info.androidhive.tabsswipe.R;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class ThongTinNguoiDung extends Fragment implements View.OnClickListener {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.thongtinnguoidung, container, false);
		
		hotenEdt = (EditText)rootView.findViewById( R.id.hoten_edt );
		ngaydangnhap = (EditText)rootView.findViewById( R.id.ngaydangnhap );
		tendangnhap = (EditText)rootView.findViewById( R.id.tendangnhap );
		cauhoibaomat = (EditText)rootView.findViewById( R.id.cauhoibaomat );
		ngaycapnhat = (EditText)rootView.findViewById( R.id.ngaycapnhat );
		ngaytao = (EditText)rootView.findViewById( R.id.ngaytao );
		chinhsuaBtn = (Button)rootView.findViewById( R.id.chinhsua_btn );

		chinhsuaBtn.setOnClickListener(this);
		
		
		// lay chi tiet thong tin
		NguoiDung user = new NguoiDung();
		
		QuanLyUser quanLyUser = new QuanLyUser(getActivity());
		
		Intent intent= getActivity().getIntent();
        Bundle b = intent.getExtras();

        if(b!=null)
        {
            String username =(String) b.get("username");
            user = quanLyUser.ThongTinChiTietTheoTenDangNhap(username);
            hotenEdt.setText(user.getHoTen());
            tendangnhap.setText(user.getTenDangNhap());
            cauhoibaomat.setText(user.getCauHoiBaoMat());
            ngaydangnhap.setText(user.getNgayDangNhap());
            ngaycapnhat.setText(user.getNgayCapNhat());
            ngaytao.setText(user.getNgayTao());
        }
        
        
        
		return rootView;
	}

	private EditText hotenEdt;
	private EditText tendangnhap;
	private EditText cauhoibaomat;
	private EditText ngaydangnhap;
	private EditText ngaycapnhat;
	private EditText ngaytao;
	private Button chinhsuaBtn;

	
	@Override
	public void onClick(View v) {
		if ( v == chinhsuaBtn ) {
			// Handle clicks for chinhsuaBtn
			String name = hotenEdt.getText().toString();
			
			QuanLyUser quanLyUser = new QuanLyUser(getActivity());
			
			Intent intent= getActivity().getIntent();
	        Bundle b = intent.getExtras();
	        if(b!=null){
	        	String username =(String) b.get("username");
	        	quanLyUser.suaHoTen(username, name);
	        }
		}
	}


	
}